# HTML常用标签
## 1 meta标签
    <head>标签的子标签，用来定义html文档的相关信息。
    meta标签可以分成两大部分：HTTP标签信息（http-equiv）和页面描述信息（name）。
    
- 1.1 http-equiv类似于http头部协议，可以利用其设定浏览器的一些信息以正确的显示网页。http-equiv属性用于指定协议头类型，content属性用于指定协议头类型的值，常用的http-equiv类型有：
    - 1.1.1 content-type         定义用户的浏览器以何种方式加载数据，或者用哪种应用程序打开资源，  
        例如
        > `<meta http-equiv = "Content-Type" content = "text/html;charset=UTF-8" />`  
        > centent值指定以普通网页打开资源，网页的编码方式为UTF-8。

    - 1.1.2 content-language     指定页面的编码方式，此值也可以包含在content-type协议头中（如上）。

    - 1.1.3 refresh              指定页面刷新或跳转的间隔时间和跳转的资源。  
        例如 
        > `<meta http-equiv = "refresh" content = "3;url=target.html" />`  
        > 指定页面在3秒后跳转到target.html ， 如不指定url值，则3秒后刷新本页面（`content = "3"`）。

    - 1.1.4 expires              指定网页缓存的过期时间。缓存过期后，客户端请求网页时，必须从服务器上重新下载网页。

    - 1.1.5 pragma与no-cache     当http-equiv取值为pragma时，content值为no-cache，表示禁止浏览器从本地计算机的缓存中访问页面内容，这样将无法实现脱机访问。

    - 1.1.6 set-cookie           设置cookie，浏览器访问某个页面时会将cookie保存在缓存中，在下次访问时可以从缓存中读取，以提高速度。  
        必须使用GMT格式指定cookie的过期时间，如  
        > `<meta http-equiv = "set-cookie" content = "cookievalue = xxx;expires=Mon,12 May 2099 00:00:00 GMT" />`

- 1.2 页面描述信息由name属性和content属性指定。name属性用来指定要描述的页面信息的类型，content用来描述页面信息的值。
    常见的name页面信息属性如下：
    - 1.2.1 keywords             为搜索引擎提供关键字列表，
        例如  
        > `<meta name = "keywords" content = "k1,k2,k3..." />`

    - 1.2.2 description          为搜索引擎提供网页主要描述  
        例如  
        > `<meta name = "description" content = "MORE INFORMATION" />`

    - 1.2.3 author               声明网页作者

    - 1.2.4 robots               用于提示哪些页面需要索引，哪些页面不需要索引。

    content的参数有以下几种，默认为all：
    - all                        默认值，文件将被检索，页面上的链接可以被查询

    - none                       文件将不被索引，页面上的链接不可以被查询

    - index                      文件将被检索

    - follow                     页面上的链接可以被查询

    - noindex                    文件将不被检索，但页面上的链接可以被查询

    - nofollow                   文件将被检索，但页面上的链接不可以被查询

## 2 文本标签
文本、图像和超链是网页的3种基本元素，其中文本是网页发布信息的主要形式。
- 2.1 字体标签 <font>
    控制文本的显示外观，如字体大小、字体类型、颜色。
    > `<font size = "5" color = "yellow" face = "微软雅黑"> 哈哈哈 </font>`
    - 2.1.1 size 可以指定的大小范围为 1~7 ，不指定的话默认为 3 ，也可以在默认大小的基础上使用相对大小设定，如 `size="+1"`。

    - 2.1.2 color 可以指定字体的颜色，可以使用颜色名，也可以使用十六进制色号来表示颜色，如#FF0001。

    - 2.1.3 face 用来指定字体类型，类型可以分为英文字体和中文字体两种，对应类型对对应语言字体有效。

- 2.2 标题标签
    六级标题， `<h1> </h1> ~ <h6> </h6>` ，数字越大，字体越小。
    标题属于块级元素，浏览器会自动在标题前后加上空行。搜索引擎可以使用标题为网页的结构和内容编制索引，用户可以通过标题快速的浏览网页。

- 2.3 换行标签 `<br>  or <br/>`
    换行标签是空标签，没有闭合标签。尽量使用`<br/>` 标签， xml、xhtml及新标准中，不允许使用未闭合的标签(`<br>`就属于未闭合)

- 2.4 段落标签 `<p>`
    可以成对使用，也可以单独使用。和标题标签一样，段落标签属于块级元素，浏览器会自动在`<p>`标签前后加上一定空白。

    - 2.4.1 align属性
        `<p>`标签有一个align属性，用来指定文本显示时的对齐方式，可以取 left,center,right 3个值：
        > `<p> 啦啦啦  </p>`  
        > `<p align="center"> 中 </p>`  
        > `<p align="left"> 一二三<br/>四五六<br/>七八九</p>`  

- 2.5 特殊字符及字符转义
    在HTML中，如需`<`、`>`、`&`等符号，以及没有在ASCII中定义的符号在网页上作为字符显示，需要转义。  
    转义字符由三部分组成：
    - 第一部分： `&`符号
    - 第二部分： 实体名称，或者`#`加上实体编号，转义字符中，各字符间不能出现空格
    - 第三部分:  分号，表示转义字符结束

