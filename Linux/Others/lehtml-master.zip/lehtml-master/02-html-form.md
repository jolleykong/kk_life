# HTML列表知识
* 如何创建编号列表
* 如何创建项目列表
* 如何创建定义列表（definition list）
* 与列表相关的级联样式表（CSS）属性。

[TOC]

## 注意知识点
* 列表标签和每个列表项独占一行的书写方式，会更具有可读性。

## 列表
* 分三种
    1. 有序列表：有编号。
    2. 无序列表：没编号，但是每个列表项有项目符号。
    3. 定义列表：*用于呈现词汇表等由名称和描述组成的内容*
    4. *较早的、另外支持的两种*：
        1. 菜单列表`<menu>` ， HTML5时被掘弃*
        2. 字典列表`<dir>`
* 特征：
    * 每个列表都有一个指定列表类型的外部元素：
        * `<ul>`和`</ul>` 表示无序列表
        * `<ol>`和`</ol>` 表示有序列表
        * `<dl>`和`</dl>` 表示定义列表
    * 每个列表都有自己的标签：
        * 词汇列表中为`<dt>`和`<dd>`
        * 其他列表中为`<li>`
        * 注意：以前的HTML标准中，上三者的结束标签可选；HTML5中，必须使用结束标签。
1. 有序列表 `<ol>`
    * 列表标签 `<ol>`,`</ol>`
    * 列表项标签 `<li>`,`</li>`
    1. 显示有序列表时，浏览器缩进列表项并自动加上编号，无需手动编号。当列表项发生变化时，重新加载页面，浏览器会重新编号。
    2. 在有序列表中，每一个列表项都有编号或某种计数器（字母或罗马数字）
    3. 仅当列表项的顺序很重要时，才应使用带编号的列表项。
    ```
    <!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title> 列表测试页 </title>
    </head>
    <body>
        <h1>这是一个有序列表</h1>
        <p>显示四个步骤</p>
        <ol>
            <li>第一步</li>
            <li>第二步</li>
            <li>第三步</li>
            <li>第四步</li>
        </ol>
    </body>
    </html>
    ```
    4. 定制有序列表 **引入CSS咯**
        * 有序列表特有的定制有两种：
            1. 一种是修改列表的编号样式；
                1. **使用CSS属性 list-sytle-type**
                2. 使用属性(attribute) type **<font color="red">（HTML5中已掘弃）</font>**
            2. 一种是修改编号本身。
        *  有序列表的编号样式
            CSS属性list-style-type | 属性type值 | 描述 
            :-|:-|:-
            decimal     | 1 | 标准阿拉伯数字，1，2，3……
            lower-alpha | a | 小写字母
            upper-alpha | A | 大写字母
            lower-roman | i | 小写罗马字母，i,ii,iii,iv……
            upper-roman | I | 大写罗马字母，I,II,III,IV……
        * 指定编号类型：
            ```
            <p>用css指定编号类型为小写字母：</p>
            <ol style="list-style-type: lower-alpha;">
                <li>第一步</li>
                <li>第二步</li>
                <li>第三步</li>
                <li>第四步</li>
            </ol>
            ```
            ```
            <p>用css指定编号类型为大写字母，从10开始编号：</p>
            <ol style="list-style-type: upper-alpha;" start="10">
                <li>第一步</li>
                <li>第二步</li>
                <li>第三步</li>
                <li>第四步</li>
            </ol>
            ```
            ```
            <p>用css指定编号类型为大写字母，从10开始编号，第二项从2开始编号</p>
            <ol style="list-style-type: upper-alpha;" start="10">
                <li>第一步</li>
                <li>第二步</li>
                <li value="2">第三步</li>
                <li>第四步</li>
            </ol>
            ```
2. 无序列表 `<ul>`
    * 列表标签`<ul>`、`</ul>`
    * 列表项标签`<li>`、`</li>`

    1. 无需列表的定制：
        1. **使用CSS属性 list-sytle-type**
        2. 使用属性(attribute) type **<font color="red">（HTML5中已掘弃）</font>**
    2. 无序列表的项目符号样式：  
        CSS属性list-style-type属性type值 | 描述 
        :-|:-
        disc    |   圆盘。默认样式
        square  |   实心正方形
        circle  |   空心圆
        * 定制无序列表
            ```
            <p>可爱的无序列表：</p>
            <ul>
                <li>李子</li>
                <li>苹果</li>
                <li>孩子</li>
                <li>狗子</li>
                <li>傻子</li>
            </ul>
            ```
            ```
            <p>可爱的方块列表：</p>
            <ul style="list-style-type: square;">
                <li>李子</li>
                <li>苹果</li>
                <li>孩子</li>
                <li>狗子</li>
                <li>傻子</li>
            </ul>
            ```
    3. 自定义项目符号样式：
        * 通过设置`list-style-image`属性，可以使用图像来替换项目符号。
            ```
            <ul style="list-style-image: url(/a.gif);">
                <li>我是一个列表项目</li>
            </ul>
            ```
    4. 自定义对齐方式
        * 列表项横跨多行时，后续行默认与第一行左对齐。如果希望后续行与项目符号或列表编号对齐而不是与第一行文字对齐，可以使用`list-style-position`属性，默认为`outside`，可指定为`inside`。
            ```
            <ul style="list-style-position: inside;">
                <li>假定我可以换行吧!巴拉巴拉巴拉嘻嘻嘻呼呼呼啦啦啦叽叽叽咔咔咔咯咯咯</li>
                <li>假定我可以换行吧</li>
                <li>假定我可以换行吧</li>
            </ul>
            ```
    5. 同时定义多个列表相关属性的快捷属性`<list-style>`
        * 多合一
            ```
            <ul style="list-style: square inside url(/a.gif);">
                <li>我是一个列表项目</li>
            </ul>
            ```
3. 定义列表 `<dl>`  --> `<dt>`&`<dd>`
    * 定义列表与有序无序列表有些不同，每个列表项都包含两部分：
        1. 术语，对应标签为`<dt>`
        2. 术语的定义，对应标签为`<dd>` 
    * 浏览器中显示定义列表时，术语和定义通常时分开的并且缩进定义。
        ```
        <dl>
            <dt>希尔瓦娜斯</dt>
            <dd>Sylvanas，被遗忘者的首领。</dd>
            <dt>萨尔</dt>
            <dd>部落的前首领，<p>兽人，</p>战士&萨满，大地之环成员。</dd>
        </dl>
        ```
4. 嵌套列表
    * 可根据喜好修改列表的编号和项目符号样式
    * 可随意嵌套列表，不限层数
    * 不要使用已掘弃的列表类型
    * 不要手工给列表编号或设置格式，应使用列表标签来做
    * 不要使用列表标签来实现对文本的缩进，应使用CSS来实现 
    ```
        <p>现在开始列表嵌套大乱斗啦：</p>
    <ol>
        <li>第一层第一条</li>
        <li>第二层第一条</li>
        <li>
            <ol>
                <li>第三层第一条</li>
                <li>第三层第二条</li>
                <li value="10">第三层第三条</li>
                <li>
                    <ul>
                        <li>第四层第一条</li>
                        <li>第四层第二条</li>
                        <li>
                            <ul style="list-style-type: cricle;">
                                <li>第五层第一条</li>
                                <li>第五层第二条</li>
                                <li>
                                    <dt>HTML</dt>
                                    <dd>超文本标记语言</dd>
                                    <dt>CSS</dt>
                                    <dd>级联样式表</dd>
                                    <dt>看看定义能嵌套些什么</dt>
                                    <dd>
                                        <ul>
                                            <li>懒</li>
                                            <li>不想写了</li>
                                        </ul>
                                    </dd>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ol>
        </li>
    </ol>
    ```
5. 列表的其他玩法
    * 鉴于列表提供的结构，很多常见的web设计元素结构都类似于列表
    * 列表结合CSS可以将导航链接组合成类似菜单一样的元素。
    * 引入CSS后，列表是网页的核心构建快之一。


* 列表总结

HTML
标签 | 属性 | 用途
:-|:-|:-
`<ol>..</ol>`| | 带编号的有序列表，列表项以`<li>`开头。
` `| type | 指定列表使用的编号方案，在HTML5中已被CSS取代。
` `| start| 指定列表的起始编号。
`<ul>..</ul>`| |带项目符号的无序列表，列表项以`<li>`开头。
` `| type | 指定列表使用的项目符号类型，在HTML5中已被CSS取代。
 `<li>..</li>`| | 有序列表、无序列表、菜单列表、目录列表中的列表项。
 ` `| type | 重新设置当前列表项的编号或项目符号类型，仅适用于`<ul>`和`<ol>`列表，在HTML5中已经被CSS取代。
 ` `| value | 在有序列表`<ol>` 中间重新开始编号。
 `<dl>..</dl>`| | 词汇列表或定义列表，其中的列表项包含两部分：术语和定义。
 `<dt>..</dt>`| | 定义列表中列表项的术语部分
 `<dd>..</dd>`| | 定义列表中列表项的定义部分

CSS
属性 | 用途/取值
:-|:-
`list-style-type`| 用于指定列表的项目符号或编号样式，可能的取值包括：`disc`、`circle`、`square`、`decimal`、`lower-roman`、`upper-roman`、`lower-alpha`、`upper-alpha`、`none`。
`list-style-image`| 指定用作列表项目符号的图像，取值为对应图像的URL.
`list-style-position`| 指定列表项后续行与第一行的对齐方式，取值包括`inside`、`outside(默认)`
`list-style`| 能够同时设置上面三个属性。