# 使用HTML和CSS进行文本格式设置
* 指定字符外观（粗体、斜体、下划线）
* 包含特殊字符（重音字符、版权标记）
* 创建预定格式的文本（保留空格和制表符的文本）
* 左、右、居中对齐文本
* 修改字体和字号
* 创建其他HTML文本元素，包括换行符、水平分割线、地址和引文。
---
## 字符级元素
* **块级元素** ：使用HTML标签来创建段落、标题或列表时，这些标签影响整块文本：修改字体、修改前后行距、添加字符（无序列表），被称为**块级元素**
* **字符级元素** ：影响其他HTML标签中单词或字符的标签。它们修改这些文本的外观，使其不同于周围的文本，例如，设置为粗体或下划线。
    > 目前接触到的元素里，`<p>`、`<ul>`、`<h1>`都属于块级元素
    > `<a>`是字符级元素。

    * 在HTML4中，不能再字符级元素中嵌套块级元素，如：标题用作链接时，只能在标题标签中嵌套`<a>`标签。  
    * 但是在HTML5中，不再延续这种规则。HTML5允许在标签`<a>`中包含整个段落或其他内容块，从而将他们转换为链接。
    > 要修改文本中一系列的字符外观，可使用两种办法：  
    > *  *HTML语义标签*  
    >   或  
    > *  *级联样式表（CSS）*  
### HTML语义标签
* 语义标签描述了它包含的文本的*含义*，而不是这些文本在浏览器中的*外观*。
    * 指出包含的内容是一个定义、代码片段或要突出的单词。
    * 语义标签成对使用，影响起始标签和结束标签之间的文本。

标签|语义
:-|:-
`<em>`|以某种方式突出字符。浏览器一般显示为斜体。
`<strong>`|字符比使用`<em>`时更为突出。通常显示为粗体。
`<code>`|指出包含的是代码示例。通常使用等宽字体显示。
`<samp>`|指出包含的是示例文本。通常像`<code>`一样使用等宽字体显示。
`<kbd>`|标示需要用户输入的文本。也用等宽字体显示。
`<var>`|标示需要用实际值替换的变量或其他实体的名称，通常显示为斜体或带下划线。
`<dfn>`|标示定义。用于突出要定义或刚定义的单词，通常使用斜体显示。
`<cite>`|标示引用的作品名。通常显示为斜体。
`<abbr>`|标示缩略语。

*在HTML5中，对缩略语只支持`<abbr>`。`<acronym>`因重复被删除，但依然能够见到。实际上，应该使用标签`<abbr>`*

#### HTML5物理样式标签的变化
* 随着HTML发展，添加了一些HTML物理样式。**不应使用物理样式标签，而应该使用CSS或等价的HTML语义标签**
* 下面说明这些标签在HTML5中的语义，用来理解和非要使用的情况下使用。

标签 | 语义
:-|:-
`<b>` | 通常显示为粗体的文本。
`<i>` | 通常显示为斜体文本。
`<u>` | 下划线文本。
`<small>` | 使用小字号显示文本。
`<sub>` | 下标。
`<sup>` | 上标。

---

## 使用CSS设置字符格式
* 前面介绍的标签都可以使用CSS来实现。
* 属性`style`可用于大多数标签。  
大多数标签都以某种方式影响其包含的文本的外观，但`<span>`标签对包含的文本没有**任何**影响 
    * `<span>`标签存在的目的就是与CSS相关联。  
    * `<span>`标签与其他标签用法一样，成对使用：
        > `<p>`我是一段用来`<span>`演示的`</span>`文字`</p>`  
 
    *单独使用`<span>`标签时不会有任何效果，与属性style结合使用时，可以取代前面接触的所有标签，而且效果会更好。*

### text-decoration 属性（文本装饰）
1. 用于指定要对标签内的文本应用哪种装饰。  
* 可取值：  
    * `underline`
    * `overline`
    * `line-shrough`
    * `blink`
    > `<p>`我是一段用来`<span style="text-decoration: underline;">`演示的`</span>`文字`</p>`  

2. 在所有包含文本的标签里，都可以使用这些样式以及后续介绍的其他属性。  
    > `<h2 style="text-decoration: overline;">`我是一个用来演示的标题`</h2>`

### 字体属性
1. 字体属性几乎可以修改浏览器渲染文本时使用的字体的任何方面。
    * font-style : 斜体
        * `normal`    默认值
        * `italic`    像标签`<i>`那样渲染文本
        * `oblique`   标准字体的倾斜版本
        * 字体多数为斜体，自行独立于正常版本或倾斜版。当设置为`italic`和`oblique`时，浏览器将选择两者中可用的那个。如果两者都没安装，浏览器会生成字体的倾斜版本。
        ```
        <p><span style="font-style: italic;">试试我会不会变成斜体italic</span></p>
        <i>物理样式的斜体</i> 
        <p><span style="font-style: oblique;">试试我会不会变成斜体oblique</span></p>
        <p><span style="font-style: normal;">我肯定是普通字体</span></p>
        ```
        
    * font-weight ：字体粗细
        * `bold`
        * `bolder`
        * `lighter`
        * `100-900` 粗细单位
        * 有些情况下，计算机安装了字体的粗体版、斜体、正常版，但是没有粗斜体版。如果设置文本时将斜体和粗体套用，浏览器将创建粗体倾斜版，这通常显示得很难看。如果需要获得漂亮的效果，务必只指定通常情况下会安装的字体版。
        ```
        <p><span style="font-weight:bold;">bold样式</span></p>
        <p><span style="font-weight:bolder;">bolder样式</span></p>
        <p><span style="font-weight:lighter;">lighter样式</span></p>
        <p><span style="font-weight:100;">100样式</span></p>
        <p><span style="font-weight:200;">200样式</span></p>
        <p><span style="font-weight:300;">300样式</span></p>
        <p><span style="font-weight:400;">400样式</span></p>
        <p><span style="font-weight:500;">500样式</span></p>
        <p><span style="font-weight:600;">600样式</span></p>
        <p><span style="font-weight:700;">700样式</span></p>
        <p><span style="font-weight:800;">800样式</span></p>
        <p><span style="font-weight:900;">900样式</span></p>
        ```
        > <p><span style="font-weight:bold;">bold样式</span></p>
        > <p><span style="font-weight:bolder;">bolder样式</span></p>
        > <p><span style="font-weight:lighter;">lighter样式</span></p>
        > <p><span style="font-weight:100;">100样式</span></p>
        > <p><span style="font-weight:200;">200样式</span></p>
        > <p><span style="font-weight:300;">300样式</span></p>
        > <p><span style="font-weight:400;">400样式</span></p>
        > <p><span style="font-weight:500;">500样式</span></p>
        > <p><span style="font-weight:600;">600样式</span></p>
        > <p><span style="font-weight:700;">700样式</span></p>
        > <p><span style="font-weight:800;">800样式</span></p>
        > <p><span style="font-weight:900;">900样式</span></p>

    * font-family : 字体系列,指定字体系列。
        * `serif`
        * `sans-serif`
        * `cursive`
        * `fantasy`
        * `monospace`   等宽
        ```
        <h1>测试font-family字体系列：</h1>
        <p><span style="font-family:serif;">测试字体系列：serif</span></p>
        <p><span style="font-family:sans-serif;">测试字体系列：sans-serif</span></p>
        <p><span style="font-family:cursive;">测试字体系列：cursive</span></p>
        <p><span style="font-family:fantasy;">测试字体系列：fantasy</span></p>
        <p><span style="font-family:monospace;">测试字体系列：monospace</span></p>
        ```
        > <h1>测试font-family字体系列：</h1>
        > <p><span style="font-family:serif;">测试字体系列：serif</span></p>
        > <p><span style="font-family:sans-serif;">测试字体系列：sans-serif</span></p>
        > <p><span style="font-family:cursive;">测试字体系列：cursive</span></p>
        > <p><span style="font-family:fantasy;">测试字体系列：fantasy</span></p>
        > <p><span style="font-family:monospace;">测试字体系列：monospace</span></p>

    * font-variant ：将小写字母渲染成大写字母
        * `normal`
        * `small-caps`
        * 这个功能HTML标签无法实现。
        ```
        <h1>font-variant属性</h1>
        <p><span>我是普通字体:real normal without style.</span></p>
        <p><span style="font-variant:normal;">我是普通字体normal</span></p>
        <p><span style="font-variant:small-caps">我是普通字体small-caps</span></p>
        ```
        > <h1>font-variant属性</h1>
        > <p><span>我是普通字体:real normal without style.</span></p>
        > <p><span style="font-variant:normal;">我是普通字体normal</span></p>
        > <p><span style="font-variant:small-caps">我是普通字体small-caps</span></p>

## 预定格式的文本 `<pre>`
* HTML代码中包含的多余空白字符都会被浏览器删除
* 预定格式文本标签`<pre>`中的文本内容，包括所有空白都会保留到最终输出。
* 通过`<pre>`标签，可在显示页面中保留HTML代码中文本的间隔间距等。
* 由于显示预定格式文本常用等宽字体显示，因此非常适合显示代码示例，甚至也可以创建表格。
* `<pre>`标签内的文本中，可使用链接标签`<a>`和字符样式，但不能使用标题和段落等元素标签。
    * 使用硬回车进行换行，并尽可能让每行的长度不超过60个字符。
    * 慎用制表符，应将其转换为空格，以避免不同浏览器解释TAB长度的差异而导致格式错乱。
* `<pre>`标签页非常适合快速简单的将纯文本格式文件（如邮件）转换为HTML，只需要将邮件内容放在标签中，就转换成了HTML。
* 可以在网页上创建ASCII字符画。
    ```
    <h1 id="part3">预定格式文本：</h1>
    <pre>
        1   2   3   4   5   6   7   8   9   0
        A       *       *       *       *
        B   *       *       *       *       *
        C   *   *                       *   *
        D       *   *               *   *
        E               *       *       
        F                   *
                    <span style="font-family:fantasy;">一个像<a href="http://www.baidu.com">心</a>的字符画</span>
                    <span style="font-family:fantasy;">abcdefghijklmnopqrstuvwxyz</span>
    </pre>
    ```
    > <pre>
    >     1   2   3   4   5   6   7   8   9   0
    >     A       *       *       *       *
    >     B   *       *       *       *       *
    >     C   *   *                       *   *
    >     D       *   *               *   *
    >     E               *       *       
    >     F                   *
    >                 <span style="font-family:fantasy;">一个像<a href="http://www.baidu.com">心</a>的字符画</span>
    >                 <span style="font-family:fantasy;">abcdefghijklmnopqrstuvwxyz</span>
    > </pre>

## 水平分隔线（主题分割）`<hr />`
* `<hr>`标签，创建一条水平线。
* 在HTML5中，用来做**主题分隔**语义标签。
* `<hr>`标签，没有结束标签，可在标签名后加空格与`/`。
    * 即便这个标签包含属性，**斜杠也应该位于标签名后面**。

* `<hr>`标签的属性
    * 如果遵循的是HTML5标准，`<hr>`元素支支持所有元素都支持的属性。
    * 在以前版本的HTML中，`<hr>`元素支持很多可用于修改水平线外观的属性，在创建新网页时，水平线外观应该使用CSS来设置样式，但是在已经存在的HTML文档中可能会看到这些古老的属性。

        属性 | 含义
        :-|:-
        size | 标签属性，指定水平线粗细，单位是像素，默认2像素，也是能创建最细的水平线。
        height | **CSS属性**，水平线粗细
        width | **CSS属性**，水平线宽度，可以时特定的像素数，或屏幕宽度的百分比。会根据窗口大小自动调整。


        ```
        <h1 id="part4">主题分隔水平线的属性：</h1>
        <p>标签属性 size 2</p>
        <hr / size="3">
        <p>标签属性 size 10</p>
        <hr / size="10">
        <p>css属性 width宽度50%</p>
        <hr / width="50%">
        <p>css属性 width宽度100像素,size 50</p>
        <hr / width="100" size="50">
        ```
        > <p>标签属性 size 2</p>
        > <hr / size="3">
        > <p>标签属性 size 10</p>
        > <hr / size="10">
        > <p>css属性 width宽度50%</p>
        > <hr / width="50%">
        > <p>css属性 width宽度100像素,size 50</p>
        > <hr / width="100" size="50">

* 大多数浏览器自动将标签`<hr>`表示的水平线居中。
    * 如果指定的水平线比浏览器宽度小，还可以使用属性`align`指定水平线的对齐方式（left、right、center）
    * HTML5中，所有元素曾支持的`align`属性也被CSS取代。
    * 已掘弃的属性`noshade`让浏览器将水平线绘制为没有三维投影的普通线条。

        ```
        <hr / width="100" size="50" noshade align="left">
        ```
        > 宽度100，size 50，不做投影，左对齐：
        > <hr / width="100" size="50" noshade align="left">

## 换行 `<br />`
* 在所处的位置换行。
* 缩进程度与当前元素的左边距相同。
* 可以在其他元素，如段落或列表中使用换行，换行不会增加新行的行前后距，也不会改变当前实体的字体和样式，只是重启一行显示后续文本。
* 一个已经掘弃的属性`clear`
    * 用来让文本绕排图像。已经被CSS取代。后面会详细介绍。

## 地址标签 `<address>`
* 用来在网页中提供联系信息，通常位于网页底部，指出网页开发者、客服、版权登信息。
* 属于块级标签，有些浏览器将其中文本显示为斜体。
    ```
    <p>这部分是address：</p>
    <address>
        我们邀请了MIUI安全中心产品经理做客小米8点档，<br/>
        为大家详细解读如何使用“SOS紧急求助”功能。<br/>
        我们还准备了一些小米运动蓝牙耳机mini送给大家，记得来哦。<br/> 
    </address>
    ```
    > <p>这部分是address：</p>
    > <address>
    >     我们邀请了MIUI安全中心产品经理做客小米8点档，<br/>
    >     为大家详细解读如何使用“SOS紧急求助”功能。<br/>
    >     我们还准备了一些小米运动蓝牙耳机mini送给大家，记得来哦。<br/> 
    > </address>

## 引文标签 `<blockquote>`
* 用于指出文本快为引文。属于块级元素。
* 默认情况下`<blockquote>`元素被缩进，但可以用CSS修改这种行为。
* `<blockquote>`标签只支持一个属性——`cite`，属性的值指出了标签`<blockquote>`中引文的URL。(**并不影响页面的外观**) 建议不使用。
* 标签`<cite>`则在网页上指出了引用的作品的作者、名称或URL。
* 
    ```
    <p>接下来是引文：</p>
    有一天，她走在森林里<br/>
    看到皑皑白雪后，<br/>她忍不住伸出手去<br/>触摸未曾见过的白雪。<br/>
    <blockquote cite="http://www.google.com">这一定是上帝赐给我们的。</blockquote>她心里想着。<br/>
    ```
    > <p>接下来是引文：</p>
    > 有一天，她走在森林里<br/>
    > 看到皑皑白雪后，<br/>她忍不住伸出手去<br/>触摸未曾见过的白雪。<br/>
    > <blockquote cite="http://www.google.com">这一定是上帝赐给我们的。</blockquote>她心里想着。<br/>
* 对于内嵌的引文，应该使用`<p>`标签，还可以使用属性`cite`来标识它们并提供源URL，标签`<q>`也不影响页面的视觉效果。*(在我测试的过程中发现，`<q>`标签是有效果的——自动添加了特有的双引号，可能是浏览器自动渲染的？)*
    ```
    <p>内嵌引文使用q标签：</p>
    <p>她悠悠的走着，仿佛一切都是美好的。<q cite="01.html-test.html">不然怎能开心呢！</q></p>
    ```
    > <p>内嵌引文使用q标签：</p>
    > <p>她悠悠的走着，仿佛一切都是美好的。<q cite="01.html-test.html">不然怎能开心呢！</q></p>

* 元素`<cite>`用来指出作品的作者、名称或者URL。与`<q>`标签一样，默认对网页的视觉效果没有任何影响，但是通过使用CSS可设置这两个标签的样式。
    * **标签`<cite>`的内容再网页上是可见的。** 在引文中建议使用来指出作品的作者、名称或URL等信息。
    ```
    <p>元素cite：</p>
    <p>她悠悠的走着，仿佛一切都是美好的。<cite>不然怎能开心呢！</cite><br/> 但是爷爷的话还是不时的回荡在脑海中，<cite>女孩子还打架，没教养！</cite></p>
    ```
    > <p>元素cite：</p>
    > <p>她悠悠的走着，仿佛一切都是美好的。<cite>不然怎能开心呢！</cite><br/> 但是爷爷的话还是不时的回荡在脑海中，<cite>女孩子还打架，没教养！</cite></p>

## 特殊字符
* 实际上，HTML文件为ASCII文本，应该只包含键盘上有的字符，不应该包含格式设置和花哨的字符。如果一个字符需要组合键才能输入（ALT+xxxx？），就不能在HTML文件中包含它，包括破折号之类的字符。
### 字符实体
* 在HTML文件中使用一组特殊编码来表示要使用的字符，浏览器根据所在平台及安装的字体，将他们显示为相应的特殊字符。
* 有些特殊字符并非源自扩展的ASCII字符集，例如`引号`和`&`虽然包含在标准ASCII字符集中，但是在网页中可以使用字符实体来表示。
* 有些字符在HTML文档中有特殊含义，可以使用字符实体来表示，避免浏览器解析时出现问题。
* 字符实体有两种形式：
    1. 命名实体
        * 以字符`&`开头，并以`;`结尾，中间是字符名（常见字符名的简写），字符名区分大小写。命名实体与网页文件所使用的字符集关系不大因为浏览器会把命名实体转换为网页使用的字符集中的对应字符。
            * `&quot;`
            * `&copy;`
    2. 编号实体
        * 编号实体和命名实体类似，以字符`&`开头，以`;`结尾，但是中间不是字符名，而是`#`和编号，编号为**字符在网页使用的字符集**中的位置，使用*十进制*表示。
            * `&#224;`
            * `&#233;`
### 字符编码
* 要在网页中添加特殊字符，先要了解字符编码。  
    * 在ASCII字符集中，空格排在第32位，使用十六进制表示时，(32)<sub>10</sub>=(20)<sub>16</sub>，这就是空格字符在URL编码为`%20`的原理，在URL对字符进行编码时，使用的就是它在ASCII中的排位。
    * 显示网页时，浏览器在使用的字符集中查找网页上的所有字符。如果网页没有指定，浏览器将使用默认编码来显示网页。
    * 大多数情况下，如果只使用ASCII字符集中的128个字符，网页就能够正确的显示，无论用户选择哪种编码。如果使用了128个字符外的其他字符，就可能出现问题。
    * 为确保字符正确显示，指定网页使用`UTF-8`编码就好了，对于不属于ASCII字符集的字符，使用字符实体来表示他们。
        * 设定网页使用的字符集：
        > 在`<head>`标签中通过`<meta charset="UTF-8">`的方式指定网页字符集为`UTF-8`
### 表示特殊字符的字符实体
* 在HTML文件中，可以在要放置字符的地方使用编号实体或命名实体（具体内容参照上两节：#字符实体的两种形式#）

### 表示保留字符的字符实体
* 字符实体能够在网页中包含不属于标准ASCII字符集的特殊字符，然而有几个字符是例外的，它们在HTML中有特殊含义，对于这些字符，必须使用字符实体来表示。  
  
    如果要在HTML文件中包含这样一行代码：  
    ```
    <p><code>if x < y do print i </code></p>
    ```
    由于`<`是HTML“标签起始位置”，在上面的代码中，小于号就会使浏览器出现解析问题(当然了，现在浏览器几乎都能自动更正这个问题)，为了确保代码在HTML中合法，应该将保留字符通过字符实体来表示：
    ```
    <p><code>if x &lt; y do print i </code></p>
    ```
    另外，要在网页内容中显示HTML标签，也需要使用字符实体来进行表示：
    ```
    <p> 段落标签&lt;p&gt;表示一个段落</p>
    ```

    标签所使用的字符的转义编码
    实体 | 结果
    :-|:-
    `&lt;` | `<`
    `&gt;` | `>`
    `&amp;` | `&`

## 字体和字号
### 使用CSS来控制网页使用的所有字体
* font-family 可指定渲染文本时应使用的字体系列，也可以使用这个属性来指定特定的字体。
* 可指定单个字体，或一个字体列表。浏览器将在系统中搜索，直到找到指定的字体之一。
* 如果愿意的话，还可以在字体列表中指定一个通用字体系列。
    ```
    <p>使用font-family来指定字体或字体列表</p>
    <p style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Who are you? 我的朋友？</p>
    <p style="font-family: 'Courier New', monospace;">Who are you? 我的朋友？</p>
    <p style="font-family: Georgia;">Who are you？ 我的朋友？</p>
    ```
    > <p>使用font-family来指定字体或字体列表</p>
    > <p style="font-family: Verdana, Geneva, Tahoma, sans-serif;">Who are you? 我的朋友？</p>
    > <p style="font-family: 'Courier New', monospace;">Who are you? 我的朋友？</p>
    > <p style="font-family: Georgia;">Who are you？ 我的朋友？</p>

* 可以使用CSS来指定字号。
    * 在指定尺寸时，CSS提供了强大的功能和极大的灵活性。
        * 可以使用各种单位。
        * font-size属性值可以是相对值或绝对值。
        * 可以使用CSS支持的任何度量单位。
    ```
    <p>使用font-size来指定字号</p>
    <p style="font-size:normal;">普通字号字体， Normal font size.</p>
    <p style="font-size: 200% ;">两倍字号字体， Twice font size.</p>
    ```

    > <p>使用font-size来指定字号</p>
    > <p style="font-size:normal;">普通字号字体， Normal font size.</p>
    > <p style="font-size: 200% ;">两倍字号字体， Twice font size.</p>

    * 值可以使用众多不同的单位指定字号，如： `px`表示像素：
        ```
        <p style="font-size: 10px ;">10px字号字体， 10px font size.</p>
        <p style="font-size: 20px ;">20px字号字体， 20px font size.</p>
        ```

        > <p style="font-size: 10px ;">10px字号字体， 10px font size.</p>
        > <p style="font-size: 20px ;">20px字号字体， 20px font size.</p>

**使用CSS控制网页字体和字号的注意事项：**
1. **CSS指定单位时，单位和数字之间不能有空格**
2. **指定字体时，一定要包含备用字体，以提高用户的系统安装了指定字体的可能性。**
3. **在同一个网页中，不要使用太多不同的字体**
4. **使用CSS指定字号时，尽可能不要使用绝对字号，有些浏览器在这种情况下会禁止用户修改文本的字号**


# 小结

## 本章涉及到的所有标签
标签        |属性   |用途
:-|:-|:-
`<address>` |       |网页落款，通常位于页面底部，包含联系信息或版权信息等。
`<b>`       |       |粗体文本
`<blockquote>`  |   |较长的引文
 --         |cite   |引文来源URL
`<cite>`    |       |文献，通常显示为斜体
`<code>`    |       |代码示例
`<dfn>`     |       |定义或要定义的术语，通常以斜体显示
`<em>`      |       |突出的文本，一般显示为斜体。
`<i>`       |       |斜体文本
`<kbd>`     |       |要由用户输入的文本，用等宽字体显示。
`<pre>`     |       |预定格式的文本，所有空白字符、制表符和换行都将保留，并以等宽字体显示。
`<q>`       |       |内嵌引文
--          |cite   |引文来源的URL
`<samp>`    |       |实力文本，通常像`<code>`一样使用等宽字体显示。
`<small>`   |       |使用比周围文本更小的字体显示文字
`<strong>`  |       |强烈突出的文本，通常显示为粗体
`<sub>`     |       |下标文本
`<sup>`     |       |上标文本
`<u>`       |       |带下划线的文本
`<var>`     |       |标示变量名，通常显示为斜体带下划线。
`<span>`    |       |通用标签，用于对文本应用样式。
`<hr>`      |       |绘制一条水平分割线。在XHTML中，标签名和属性名后添加空格和斜杠，如： `<hr size="2" width=75%" />`
--          |size   |水平分割线的粗细，单位为像素。**在HTML5中已掘弃**。
--          |width  |水平分割线的长度，可以为像素数，也可以为页面宽度的百分比，如：50%，  **HTML5中已掘弃**。
--          |align  |水平分割线与页面的对齐方式，可以是left、right、center，**HTML5中已掘弃**。
--          |noshade    |显示水平分割线时不带三维投影，**HTML5中已掘弃**。
`<br>`      |       |换行符。将后续字符重起一行进行显示，但不创建新的段落或列表项。在XHTML中，标签名和属性后添加空格和斜杠，如：`<br clear="left" />`

## 本章涉及到的CSS属性
属性   |用途及可能的取值
:-|:-
`text-decoration`   |指定要对文本应用的装饰，可能取值：`underline`、`overline`、`line-through`、`blink`、`none`。
`font-style`        |指定是否将文本设置为斜体，可能取值：`normal`、`italic`、`oblique`。
`font-weight`       |指定文本加粗的程度，可能取值：`normal`、`bold`、`bolder`、`lighter`、`100-900`。
`font-family`       |指定文本的字体或字体系列，如： serif、sans serif、monospace。也可以制定具体的字体名，还可以指定多个字体或字体系列。
`font-variant`      |设置字体变种，取值为`normal`、`small-caps`。
`font-size`         |以CSS支持的任何单位指定字号。


END.20181008.