# MySQL docker for learning .



Do Not Modify Anything until you know what you doing.



Remeber to add your local user public-SSH-key to authorized_keys before build the image.



> K.K.

